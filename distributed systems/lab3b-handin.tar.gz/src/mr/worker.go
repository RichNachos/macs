package mr

import (
	"encoding/json"
	"fmt"
	"hash/fnv"
	"io"
	"log"
	"net/rpc"
	"os"
	"sort"
	"strings"
	"time"
)

const WorkerWaitTime = 2 * time.Second

// Map functions return a slice of KeyValue.
type KeyValue struct {
	Key   string
	Value string
}

// for sorting by key.
type ByKey []KeyValue

// for sorting by key.
func (a ByKey) Len() int           { return len(a) }
func (a ByKey) Swap(i, j int)      { a[i], a[j] = a[j], a[i] }
func (a ByKey) Less(i, j int) bool { return a[i].Key < a[j].Key }

// use ihash(key) % NReduce to choose the reduce
// task number for each KeyValue emitted by Map.
func ihash(key string) int {
	h := fnv.New32a()
	h.Write([]byte(key))
	return int(h.Sum32() & 0x7fffffff)
}

// main/mrworker.go calls this function.
func Worker(mapf func(string, string) []KeyValue,
	reducef func(string, []string) string) {

	// Your worker implementation here.

	// uncomment to send the Example RPC to the coordinator.
	// CallExample()
	ok := CallCoordinatorForTask(mapf, reducef)
	for ok {
		ok = CallCoordinatorForTask(mapf, reducef)
	}
}

func CallCoordinatorForTask(mapf func(string, string) []KeyValue,
	reducef func(string, []string) string) bool {
	args := Args{}
	reply := Reply{}
	// println("Calling Coordinator for task")
	ok := call("Coordinator.RequestTask", &args, &reply)
	if ok {
		// Implement Map/Reduce task

		if reply.Task == MAP {
			// println("Received Map Task: ", reply.Input)
			Map(mapf, reply)
		}
		if reply.Task == REDUCE {
			// println("Received Reduce Task: ", reply.Input)
			Reduce(reducef, reply)
		}
		if reply.Task == WAIT {
			// println("Received Wait Task")
			time.Sleep(WorkerWaitTime)
		}
	}
	return ok
}

func SignalCoordinator(task TaskType, taskId int) {
	args := SignalArgs{}
	args.Task = task
	args.TaskId = taskId
	reply := SignalReply{}
	// println("Signaling Coordinator Task Completed")
	call("Coordinator.Signal", &args, &reply)
}

func Map(mapf func(string, string) []KeyValue, reply Reply) {
	file, err := os.Open(reply.Input)
	if err != nil {
		log.Fatalf("cannot open %v", reply.Input)
	}
	content, err := io.ReadAll(file)
	if err != nil {
		log.Fatalf("cannot read %v", reply.Input)
	}
	file.Close()
	kva := mapf(reply.Input, string(content))

	oname := fmt.Sprintf("mr-map-%v", reply.TaskId)
	ofile, _ := os.Create(oname)
	enc := json.NewEncoder(ofile)
	for _, kv := range kva {
		err := enc.Encode(&kv)
		if err != nil {
			log.Fatalf("Encoding Failed during Map")
		}
	}
	ofile.Close()
	SignalCoordinator(MAP, reply.TaskId)
}

func Reduce(reducef func(string, []string) string, reply Reply) {
	kva := []KeyValue{}

	files, _ := os.ReadDir(".")
	for _, file := range files {
		if !strings.Contains(file.Name(), "mr-map-") {
			continue
		}

		iname := file.Name()
		ifile, err := os.Open(iname)
		if err != nil {
			log.Fatalf("cannot open %v", reply.Input)
		}

		dec := json.NewDecoder(ifile)
		for {
			var kv KeyValue
			if err := dec.Decode(&kv); err != nil {
				break
			}
			if ihash(kv.Key)%reply.NReduce == reply.TaskId {
				kva = append(kva, kv)
			}
		}
	}

	// Do sequential reduce after this point
	sort.Sort(ByKey(kva))

	oname := fmt.Sprintf("mr-out-%v", reply.TaskId)
	ofile, _ := os.Create(oname)

	//
	// call Reduce on each distinct key in intermediate[],
	// and print the result to mr-out-0.
	//
	i := 0
	for i < len(kva) {
		j := i + 1
		for j < len(kva) && kva[j].Key == kva[i].Key {
			j++
		}
		values := []string{}
		for k := i; k < j; k++ {
			values = append(values, kva[k].Value)
		}
		output := reducef(kva[i].Key, values)

		// this is the correct format for each line of Reduce output.
		fmt.Fprintf(ofile, "%v %v\n", kva[i].Key, output)

		i = j
	}

	ofile.Close()
	SignalCoordinator(REDUCE, reply.TaskId)

}

// example function to show how to make an RPC call to the coordinator.
//
// the RPC argument and reply types are defined in rpc.go.
func CallExample() {

	// declare an argument structure.
	args := ExampleArgs{}

	// fill in the argument(s).
	args.X = 99

	// declare a reply structure.
	reply := ExampleReply{}

	// send the RPC request, wait for the reply.
	// the "Coordinator.Example" tells the
	// receiving server that we'd like to call
	// the Example() method of struct Coordinator.
	ok := call("Coordinator.Example", &args, &reply)
	if ok {
		// reply.Y should be 100.
		fmt.Printf("reply.Y %v\n", reply.Y)
	} else {
		fmt.Printf("call failed!\n")
	}
}

// send an RPC request to the coordinator, wait for the response.
// usually returns true.
// returns false if something goes wrong.
func call(rpcname string, args interface{}, reply interface{}) bool {
	// c, err := rpc.DialHTTP("tcp", "127.0.0.1"+":1234")
	sockname := coordinatorSock()
	c, err := rpc.DialHTTP("unix", sockname)
	if err != nil {
		log.Fatal("dialing:", err)
	}
	defer c.Close()

	err = c.Call(rpcname, args, reply)
	if err == nil {
		return true
	}

	fmt.Println(err)
	return false
}
