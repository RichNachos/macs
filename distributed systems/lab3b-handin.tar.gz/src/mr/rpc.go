package mr

//
// RPC definitions.
//
// remember to capitalize all names.
//

import (
	"os"
	"strconv"
	"time"
)

const WorkerDieTime = time.Second * 10

type TaskType int
type Status int

const (
	MAP      TaskType = 0
	REDUCE   TaskType = 1
	WAIT     TaskType = 2
	FINISHED TaskType = 3
)

const (
	DONE        Status = 0
	IN_PROGRESS Status = 1
	READY       Status = 2
)

//
// example to show how to declare the arguments
// and reply for an RPC.
//

type ExampleArgs struct {
	X int
}

type ExampleReply struct {
	Y int
}

type Args struct {
}

type Reply struct {
	Task    TaskType
	TaskId  int
	Input   string
	NReduce int
}

type SignalArgs struct {
	Task   TaskType
	TaskId int
}

type SignalReply struct {
}

// Add your RPC definitions here.

// Cook up a unique-ish UNIX-domain socket name
// in /var/tmp, for the coordinator.
// Can't use the current directory since
// Athena AFS doesn't support UNIX-domain sockets.
func coordinatorSock() string {
	s := "/var/tmp/5840-mr-"
	s += strconv.Itoa(os.Getuid())
	return s
}
