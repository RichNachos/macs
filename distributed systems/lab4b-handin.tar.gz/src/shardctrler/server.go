package shardctrler

import (
	"sync"
	"time"

	"6.5840/labgob"
	"6.5840/labrpc"
	"6.5840/raft"
)

type Type uint

const (
	JOIN Type = iota
	LEAVE
	MOVE
	QUERY
)

type ShardCtrler struct {
	mu      sync.Mutex
	me      int
	rf      *raft.Raft
	applyCh chan raft.ApplyMsg

	// Your data here.

	configs []Config // indexed by config num

	// 4A
	dbMap     map[int64]bool  // Map for duplicated operation
	mucmd     sync.Mutex      // Ensures that our shard commands are parallelized safely
	config    int             // Current config index, starts from zero
	persister *raft.Persister // Persistence object
}

// Op struct
// Command which we send to raft instances

type Op struct {
	// Your data here.

	// 4A
	Config   Config
	ConfigId int
	Id       int64
	Cmd      Type
}

// Create identical config
func copyConfig(old Config) Config {
	new := Config{}
	new.Num = old.Num + 1               // num has to be +1 compared to old
	new.Groups = make(map[int][]string) // initialize groups map

	// new.Shards initialized already
	// Fill shards array with same values
	for i := range [NShards]int{} {
		new.Shards[i] = old.Shards[i]
	}

	// Fill map with string arrays
	for key, values := range old.Groups {
		// Initialize values array
		copiedValues := make([]string, len(values))
		// Copy into initialized array
		copy(copiedValues, values)
		// Set map key/value to the copied array value
		new.Groups[key] = copiedValues
	}

	// return copied config
	return new
}

// Create shards for our given config
func createShards(config Config) [NShards]int {
	// Initialize our shards array to return
	shards := [NShards]int{}

	// Initialize our group ids array
	groupIds := []int{}
	for i := range config.Groups {
		groupIds = append(groupIds, i)
	}

	// If groupIds array is nonzero in length make shards equal to corresponding values
	if len(groupIds) > 0 {
		for i := range shards {
			// Make sure shard doesnt have nonexistent groupid
			idx := i % len(config.Groups)
			shards[i] = groupIds[idx]
		}
		return shards
	}

	// If groupIds array is zero returnevery shard equal to 0
	for i := range shards {
		shards[i] = 0
	}
	return shards
}

// Send a command to raft instance
func (sc *ShardCtrler) apply(cmd Op) (Config, bool) {

	// Send the command to raft
	_, _, isLeader := sc.rf.Start(cmd)

	// If raft instance isnt leader, do nothing
	if !isLeader {
		return Config{}, !isLeader
	}

	// Raft instance was leader, continue...

	// Check results for one second duration, after that stop trying
	// Realistically, it should be able to read during that one second
	// Panicing if not.
	last := time.Now()
	for time.Since(last) < time.Second {

		// Check if command was seen, if not, drop lock
		if !sc.dbMap[cmd.Id] {
			// Drop and pick up lock to let other threads run for some time
			// Not sleeping speeds up the process so its better?
			// Maybe busy waiting too much and sacrificing power for performance?
			// TODO recheck this piece of code later
			sc.mu.Unlock()
			sc.mu.Lock()
			continue
		}
		// Command seen, continue...

		// If command was not query, do nothing
		if cmd.Cmd != QUERY {
			return Config{}, !isLeader
		}

		// Command is query, continue...

		// Get valid config
		var config Config
		if cmd.ConfigId >= 0 && cmd.ConfigId <= len(sc.configs)-1 {
			// Copy existing config
			config = copyConfig(sc.configs[cmd.ConfigId])
		} else {
			// Otherwise get the latest config
			config = copyConfig(sc.configs[len(sc.configs)-1])
		}

		// Fix config index
		config.Num -= 1

		// Return our results to callee function
		return config, !isLeader
	}

	// This function shouldn't reach this point, do panic...
	panic("Apply failed for some reason...")
}

// Join RPC Logic
func (sc *ShardCtrler) Join(args *JoinArgs, reply *JoinReply) {
	// Your code here.

	// Pick up locks
	sc.mucmd.Lock()
	defer sc.mucmd.Unlock()
	sc.mu.Lock()
	defer sc.mu.Unlock()

	// if isn't leader or command already seen before reply with nothing
	_, isLeader := sc.rf.GetState()
	if !isLeader || sc.dbMap[args.Id] {
		reply.WrongLeader = true
		return
	}

	// copy existing config
	config := copyConfig(sc.configs[sc.config])

	// copy values from argument to new copied config
	// TODO might want to change? not sure
	for key, value := range args.Servers {
		config.Groups[key] = value
	}

	// generate new shards after copying everything....
	config.Shards = createShards(config)

	// Get Op struct ready
	cmd := Op{}
	cmd.Config = config
	cmd.Id = args.Id
	cmd.Cmd = JOIN

	// Ignore returned config from apply method
	_, reply.WrongLeader = sc.apply(cmd)
}

// Leave RPC Logic
func (sc *ShardCtrler) Leave(args *LeaveArgs, reply *LeaveReply) {
	// Your code here.

	// Pick up locks
	sc.mucmd.Lock()
	defer sc.mucmd.Unlock()
	sc.mu.Lock()
	defer sc.mu.Unlock()

	// if isn't leader or command already seen before reply with nothing
	_, isLeader := sc.rf.GetState()
	if !isLeader || sc.dbMap[args.Id] {
		reply.WrongLeader = true
		return
	}

	// Create new config with different shards
	config := copyConfig(sc.configs[sc.config])

	// Remove all group id mappings
	for i := range args.GIDs {
		delete(config.Groups, args.GIDs[i])
	}

	// generate new shards
	config.Shards = createShards(config)

	// Get Op struct ready
	cmd := Op{}
	cmd.Config = config
	cmd.Id = args.Id
	cmd.Cmd = LEAVE

	// Ignore returned config from apply method
	_, reply.WrongLeader = sc.apply(cmd)
}

// Move RPC Logic
func (sc *ShardCtrler) Move(args *MoveArgs, reply *MoveReply) {
	// Your code here.

	// Pick up locks
	sc.mucmd.Lock()
	defer sc.mucmd.Unlock()
	sc.mu.Lock()
	defer sc.mu.Unlock()

	// if isn't leader or command already seen before reply with nothing
	_, isLeader := sc.rf.GetState()
	if !isLeader || sc.dbMap[args.Id] {
		reply.WrongLeader = true
		return
	}

	// Create new config with different group id
	config := copyConfig(sc.configs[sc.config])
	config.Shards[args.Shard] = args.GID

	// Get Op struct ready
	cmd := Op{}
	cmd.Config = config
	cmd.Id = args.Id
	cmd.Cmd = MOVE

	// Ignore returned config from apply method
	_, reply.WrongLeader = sc.apply(cmd)
}

// Query RPC Logic
func (sc *ShardCtrler) Query(args *QueryArgs, reply *QueryReply) {
	// Your code here.

	// Pick up lock
	sc.mu.Lock()
	defer sc.mu.Unlock()

	// if isn't leader or command already seen before reply with nothing
	_, isLeader := sc.rf.GetState()
	if !isLeader || sc.dbMap[args.Id] {
		reply.WrongLeader = true
		return
	}

	// Get Op struct ready
	cmd := Op{}
	cmd.ConfigId = args.Num
	cmd.Id = args.Id
	cmd.Cmd = QUERY

	// Change reply using apply method
	reply.Config, reply.WrongLeader = sc.apply(cmd)
}

// the tester calls Kill() when a ShardCtrler instance won't
// be needed again. you are not required to do anything
// in Kill(), but it might be convenient to (for example)
// turn off debug output from this instance.
func (sc *ShardCtrler) Kill() {
	sc.rf.Kill()
	// Your code here, if desired.
}

// needed by shardkv tester
func (sc *ShardCtrler) Raft() *raft.Raft {
	return sc.rf
}

func (sc *ShardCtrler) applyTicker(applyCh chan raft.ApplyMsg) {
	for msg := range applyCh {

		// Check if received command is valid. If not, skip
		if !msg.CommandValid {
			continue
		}

		// Pick up lock to process received command

		sc.mu.Lock()
		cmd := msg.Command.(Op)

		// If command already in dbMap, do nothing
		if sc.dbMap[cmd.Id] {
			sc.mu.Unlock()
			continue
		}

		// Mark command as seen already
		sc.dbMap[cmd.Id] = true

		// If command was query, do nothing
		if cmd.Cmd == QUERY {
			sc.mu.Unlock()
			continue
		}

		// Command is now JOIN, LEAVE or MOVE

		// Check if new config overwrites or appends to existing configs list
		if cmd.Config.Num < len(sc.configs) {
			// It overwrites existing config so change it
			sc.configs[cmd.Config.Num] = cmd.Config
		}

		// If our list is too short for the next appended config to be Num index
		// add empty config structs until it fills up so that finally the last appended config
		// has Num index
		for cmd.Config.Num > len(sc.configs) {
			sc.configs = append(sc.configs, Config{})
		}

		// Add config to the list. It will always have Num index
		if cmd.Config.Num == len(sc.configs) {
			sc.configs = append(sc.configs, cmd.Config)
		}

		// increase config int by 1
		sc.config++

		// Drop lock
		sc.mu.Unlock()
	}
}

// servers[] contains the ports of the set of
// servers that will cooperate via Raft to
// form the fault-tolerant shardctrler service.
// me is the index of the current server in servers[].
func StartServer(servers []*labrpc.ClientEnd, me int, persister *raft.Persister) *ShardCtrler {
	sc := new(ShardCtrler)
	sc.me = me

	sc.configs = make([]Config, 1)
	sc.configs[0].Groups = map[int][]string{}

	labgob.Register(Op{})
	sc.applyCh = make(chan raft.ApplyMsg)
	sc.rf = raft.Make(servers, me, persister, sc.applyCh)

	// Your code here.

	// For snapshots persistence
	sc.persister = persister

	// Configure first configuration
	sc.configs[0].Num = 0
	for i := range [NShards]int{} {
		sc.configs[0].Shards[i] = 0
	}

	// Set server config to default (first) configuration
	sc.config = 0

	// initialize empty map
	sc.dbMap = make(map[int64]bool)

	// start background applyticker
	go sc.applyTicker(sc.applyCh)

	return sc
}
