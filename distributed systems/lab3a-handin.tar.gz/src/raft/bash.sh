for i in {0..20}; do
go test -run 2C -race >> output 
done