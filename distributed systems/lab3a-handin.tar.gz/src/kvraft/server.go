package kvraft

import (
	"log"
	"sync"
	"sync/atomic"
	"time"

	"6.5840/labgob"
	"6.5840/labrpc"
	"6.5840/raft"
)

const Debug = false

func DPrintf(format string, a ...interface{}) (n int, err error) {
	if Debug {
		log.Printf(format, a...)
	}
	return
}

type Type int

const (
	READ = iota
	WRITE
)

const SLEEP = 5 // In  milliseconds

type Op struct {
	// Your definitions here.
	// Field names must start with capital letters,
	// otherwise RPC will break.
	Key   string // key
	Value string // value
	CmdId int64  // ID is only mark
	Type  Type   // Read/Write
}

type KVServer struct {
	mu      sync.Mutex
	me      int
	rf      *raft.Raft
	applyCh chan raft.ApplyMsg
	dead    int32 // set by Kill()

	maxraftstate int // snapshot if log grows this big

	// Your definitions here.
	muPut sync.Mutex
	db    map[string]string
	dbMap map[int64]bool
}

func (kv *KVServer) Get(args *GetArgs, reply *GetReply) {
	// Your code here.
	kv.mu.Lock()
	defer kv.mu.Unlock()

	// Default reply
	reply.Err = ErrWrongLeader

	_, isLeader := kv.rf.GetState()
	if !isLeader {
		return
	}

	// Send a Get command to our raft leader

	cmd := Op{}
	cmd.CmdId = args.CmdId
	cmd.Key = args.Key
	cmd.Type = READ

	_, _, ok := kv.rf.Start(cmd)
	if ok {
		// Wait two seconds for msg to be sent to applyCh
		// and our ticker function to update corresponding
		// value in our dbMap

		startTime := time.Now()
		for time.Since(startTime) < 2*time.Second {
			// Check if our dbMap contains this commands id
			if kv.dbMap[cmd.CmdId] {
				// fill reply and return
				reply.Value, ok = kv.db[cmd.Key]
				if ok {
					reply.Err = OK
				} else {
					reply.Err = ErrNoKey
				}
				return
			}

			// Originally I had thought that sleeping for some amount of time would be better,
			// but if thread sleeps for more than 10ms the speed test fails.
			// Not sleeping at all also works because other threads can lock the mutex immediately after
			// current thread unlocks it.
			// Not sleeping possible cause of future bug? Not sure.
			// Probably just busywaiting and hogging cpu resources.

			// Let go of lock so dbMap updates
			kv.mu.Unlock()
			// time.Sleep(time.Duration(SLEEP) * time.Millisecond)
			kv.mu.Lock()
		}
	}
}

func (kv *KVServer) PutAppend(args *PutAppendArgs, reply *PutAppendReply) {
	// Your code here.
	kv.muPut.Lock()
	kv.mu.Lock()
	defer kv.muPut.Unlock()
	defer kv.mu.Unlock()

	// Default reply
	reply.Err = ErrWrongLeader

	// Check if we're asking correct raft instance (leader)
	_, isLeader := kv.rf.GetState()
	if !isLeader {
		return
	}

	// Check if id already exists in our map
	if kv.dbMap[args.CmdId] {
		reply.Err = OK
		return
	}
	// Our raft is leader so try to send command to it

	// Default readValue
	readValue := ""

	// Will update readValue if is Append operation
	// Put operation will use this updated readValue
	// If isn't append operation will use default empty string ""
	if args.Op == "Append" {

		// Send a Get command
		cmd := Op{}
		cmd.CmdId = nrand()
		cmd.Key = args.Key
		cmd.Type = READ

		_, _, ok := kv.rf.Start(cmd)
		if ok {
			// Wait 2 seconds for msg to be sent to applyCh
			// and our ticker function to update corresponding
			// value in our dbMap
			startTime := time.Now()
			for time.Since(startTime) < 2*time.Second {

				if kv.dbMap[cmd.CmdId] {
					// Appended to start of args.Value
					readValue = kv.db[args.Key]
					goto putLabel
				}

				// Let go of lock so dbMap updates
				kv.mu.Unlock()
				// time.Sleep(time.Duration(SLEEP) * time.Millisecond)
				kv.mu.Lock()
			}
			return
		} else {
			return
		}
	}

putLabel:
	cmd := Op{}
	cmd.Key = args.Key
	cmd.CmdId = args.CmdId
	cmd.Value = readValue + args.Value // Use readValue (is "" if just Put operation and not Append operation)
	cmd.Type = WRITE

	_, _, ok := kv.rf.Start(cmd)
	if ok {
		// Wait 2 seconds for msg to be sent to applyCh
		// and our ticker function to update corresponding
		// value in our dbMap
		startTime := time.Now()
		for time.Since(startTime) < 2*time.Second {
			if kv.dbMap[cmd.CmdId] {
				reply.Err = OK
				return
			}

			// Let go of lock so dbMap updates
			kv.mu.Unlock()
			// time.Sleep(time.Duration(SLEEP) * time.Millisecond)
			kv.mu.Lock()
		}
	}
}

// the tester calls Kill() when a KVServer instance won't
// be needed again. for your convenience, we supply
// code to set rf.dead (without needing a lock),
// and a killed() method to test rf.dead in
// long-running loops. you can also add your own
// code to Kill(). you're not required to do anything
// about this, but it may be convenient (for example)
// to suppress debug output from a Kill()ed instance.
func (kv *KVServer) Kill() {
	atomic.StoreInt32(&kv.dead, 1)
	kv.rf.Kill()
	// Your code here, if desired.
}

func (kv *KVServer) killed() bool {
	z := atomic.LoadInt32(&kv.dead)
	return z == 1
}

// Ticker go routine that checks for messages received on applyCh.
// For every message we update our db and dbMap to update the corresponding command index.
func (kv *KVServer) applyTicker(applyCh chan raft.ApplyMsg) {
	for !kv.killed() {
		for msg := range applyCh {
			// Was the command rejected? if so, ignore it
			if !msg.CommandValid {
				continue
			}

			// Command was not rejected and commited, update our db and dbMap
			kv.mu.Lock()
			cmd := msg.Command.(Op)
			if !kv.dbMap[cmd.CmdId] {
				// Set that this id command exists
				kv.dbMap[cmd.CmdId] = true
				// If command was a WRITE operation update our corresponding key-value in our db
				if cmd.Type == WRITE {
					kv.db[cmd.Key] = cmd.Value
				}
			}
			kv.mu.Unlock()
		}
	}
}

// servers[] contains the ports of the set of
// servers that will cooperate via Raft to
// form the fault-tolerant key/value service.
// me is the index of the current server in servers[].
// the k/v server should store snapshots through the underlying Raft
// implementation, which should call persister.SaveStateAndSnapshot() to
// atomically save the Raft state along with the snapshot.
// the k/v server should snapshot when Raft's saved state exceeds maxraftstate bytes,
// in order to allow Raft to garbage-collect its log. if maxraftstate is -1,
// you don't need to snapshot.
// StartKVServer() must return quickly, so it should start goroutines
// for any long-running work.
func StartKVServer(servers []*labrpc.ClientEnd, me int, persister *raft.Persister, maxraftstate int) *KVServer {
	// call labgob.Register on structures you want
	// Go's RPC library to marshall/unmarshall.
	labgob.Register(Op{})

	kv := new(KVServer)
	kv.me = me
	kv.maxraftstate = maxraftstate

	// You may need initialization code here.

	kv.applyCh = make(chan raft.ApplyMsg)
	kv.rf = raft.Make(servers, me, persister, kv.applyCh)

	// You may need initialization code here.

	// 3A
	kv.db = make(map[string]string)
	kv.dbMap = make(map[int64]bool)
	go kv.applyTicker(kv.applyCh)

	// Wait for goroutine to start
	time.Sleep(20 * time.Millisecond)

	return kv
}
