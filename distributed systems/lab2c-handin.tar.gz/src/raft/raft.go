package raft

//
// this is an outline of the API that raft must expose to
// the service (or tester). see comments below for
// each of these functions for more details.
//
// rf = Make(...)
//   create a new Raft server.
// rf.Start(command interface{}) (index, term, isleader)
//   start agreement on a new log entry
// rf.GetState() (term, isLeader)
//   ask a Raft for its current term, and whether it thinks it is leader
// ApplyMsg
//   each time a new entry is committed to the log, each Raft peer
//   should send an ApplyMsg to the service (or tester)
//   in the same server.
//

import (
	//	"bytes"
	"bytes"
	"math/rand"
	"sync"
	"sync/atomic"
	"time"

	//	"6.5840/labgob"
	"6.5840/labgob"
	"6.5840/labrpc"
)

const ( // ms
	ELECTION_MIN = 400
	ELECTION_MAX = 500
	TICKER       = 50
)

func (rf *Raft) ifTimeout() bool {
	return time.Since(rf.last) > time.Duration(rf.timeout)*time.Millisecond
}

func (rf *Raft) resetTimeout() {
	rf.timeout = ELECTION_MIN + (rand.Int() % (ELECTION_MAX - ELECTION_MIN))
}

type State int

const (
	LEADER State = iota
	CANDIDATE
	FOLLOWER
)

func (rf *Raft) resetVotes() {
	for i := range rf.peers {
		rf.votes[i] = false
	}
}

// as each Raft peer becomes aware that successive log entries are
// committed, the peer should send an ApplyMsg to the service (or
// tester) on the same server, via the applyCh passed to Make(). set
// CommandValid to true to indicate that the ApplyMsg contains a newly
// committed log entry.
//
// in part 2D you'll want to send other kinds of messages (e.g.,
// snapshots) on the applyCh, but set CommandValid to false for these
// other uses.
type ApplyMsg struct {
	CommandValid bool
	Command      interface{}
	CommandIndex int

	// For 2D:
	SnapshotValid bool
	Snapshot      []byte
	SnapshotTerm  int
	SnapshotIndex int
}

// A Go object implementing a single Raft peer.
type Raft struct {
	mu        sync.Mutex          // Lock to protect shared access to this peer's state
	peers     []*labrpc.ClientEnd // RPC end points of all peers
	persister *Persister          // Object to hold this peer's persisted state
	me        int                 // this peer's index into peers[]
	dead      int32               // set by Kill()

	// Your data here (2A, 2B, 2C).
	// Look at the paper's Figure 2 for a description of what
	// state a Raft server must maintain.
	currentTerm int
	votedFor    int
	log         []LogEntry
	state       State
	votes       []bool
	timeout     int       // ms
	last        time.Time // when peer was last interacted with
	applyCh     chan ApplyMsg

	//2B
	commitIndex int
	lastApplied int
	nextIndex   []int
	matchIndex  []int
}

type LogEntry struct {
	Index   int
	Term    int
	Command interface{}
}

// return currentTerm and whether this server
// believes it is the leader.
func (rf *Raft) GetState() (int, bool) {
	// Your code here (2A).
	rf.mu.Lock()
	defer rf.mu.Unlock()
	return rf.currentTerm, rf.state == LEADER
}

// save Raft's persistent state to stable storage,
// where it can later be retrieved after a crash and restart.
// see paper's Figure 2 for a description of what should be persistent.
// before you've implemented snapshots, you should pass nil as the
// second argument to persister.Save().
// after you've implemented snapshots, pass the current snapshot
// (or nil if there's not yet a snapshot).
func (rf *Raft) persist() {
	// Your code here (2C).
	// Example:
	w := new(bytes.Buffer)
	e := labgob.NewEncoder(w)
	e.Encode(rf.currentTerm) // this instances term
	e.Encode(rf.votedFor)    // vote was given to
	e.Encode(rf.state)       // state
	e.Encode(len(rf.log))    // log size

	for i := range rf.log {
		e.Encode(rf.log[i]) // encode every entry
	}
	for i := range rf.votes {
		e.Encode(rf.votes[i]) // encode every vote
	}

	raftstate := w.Bytes()
	rf.persister.Save(raftstate, nil)
}

// restore previously persisted state.
func (rf *Raft) readPersist(data []byte) {
	if data == nil || len(data) < 1 { // bootstrap without any state?
		return
	}
	// Your code here (2C).
	// Example:
	r := bytes.NewBuffer(data)
	d := labgob.NewDecoder(r)
	var currentTerm int
	var votedFor int
	var state State
	var logLength int
	var log []LogEntry
	var votes []bool

	d.Decode(&currentTerm)
	d.Decode(&votedFor)
	d.Decode(&state)
	d.Decode(&logLength)

	for i := 0; i < logLength; i++ {
		var entry LogEntry
		d.Decode(&entry)
		log = append(log, entry)
	}
	for i := 0; i < len(rf.peers); i++ {
		var vote bool
		d.Decode(vote)
		votes = append(votes, vote)
	}

	rf.currentTerm = currentTerm
	rf.votedFor = votedFor
	rf.state = state
	rf.log = log
	rf.votes = votes
}

// the service says it has created a snapshot that has
// all info up to and including index. this means the
// service no longer needs the log through (and including)
// that index. Raft should now trim its log as much as possible.
func (rf *Raft) Snapshot(index int, snapshot []byte) {
	// Your code here (2D).

}

// example RequestVote RPC arguments structure.
// field names must start with capital letters!
type RequestVoteArgs struct {
	// Your data here (2A, 2B).
	Term        int
	CandidateId int
	// 2B - lastlogindex and lastlogterm
	LastLogIndex int
	LastLogTerm  int
}

// example RequestVote RPC reply structure.
// field names must start with capital letters!
type RequestVoteReply struct {
	// Your data here (2A).
	Term        int
	VoteGranted bool
}

type AppendEntriesArgs struct {
	// 2A
	Term     int
	LeaderId int
	// 2B
	PrevLogIndex int
	PrevLogTerm  int
	Entries      []LogEntry
	LeaderCommit int
}

type AppendEntriesReply struct {
	// 2A
	Term    int
	Success bool
	// 2B
	NextIndex int
}

// example RequestVote RPC handler.

// GOOD
func (rf *Raft) RequestVote(args *RequestVoteArgs, reply *RequestVoteReply) {
	// Your code here (2A, 2B).
	rf.mu.Lock()
	defer rf.mu.Unlock()
	defer rf.persist()
	reply.VoteGranted = false
	reply.Term = rf.currentTerm

	if rf.currentTerm < args.Term {
		rf.turnIntoFollower()
		rf.currentTerm = args.Term
		rf.persist()
	}
	if rf.currentTerm > args.Term {
		return
	}
	if rf.state != FOLLOWER {
		return
	}
	if rf.votedFor != -1 && rf.votedFor != args.CandidateId {
		return
	}

	check := false
	if args.LastLogTerm > rf.log[len(rf.log)-1].Term {
		check = true
	}
	if args.LastLogTerm == rf.log[len(rf.log)-1].Term && len(rf.log)-1 <= args.LastLogIndex {
		check = true
	}
	if check {
		reply.VoteGranted = true
		rf.votedFor = args.CandidateId
		rf.last = time.Now()
	}
}

// example AppendEntries RPC handler

// GOOD
func (rf *Raft) AppendEntries(args *AppendEntriesArgs, reply *AppendEntriesReply) {
	// Your code here (2A, 2B).
	rf.mu.Lock()
	defer rf.mu.Unlock()
	defer rf.persist()
	reply.Term = rf.currentTerm
	reply.Success = false

	// leader has higher term so we agree to be their follower
	if rf.currentTerm < args.Term {
		rf.turnIntoFollower()
		rf.currentTerm = args.Term
		rf.persist()
	}
	// leader has lower term so we say no
	if rf.currentTerm > args.Term {
		reply.NextIndex = -1
		return
	}
	// is candidate with <= term than the leader, so turn it into follower
	if rf.state == CANDIDATE && rf.me != args.LeaderId {
		rf.turnIntoFollower()
		rf.resetVotes()
		rf.persist()
	}

	rf.last = time.Now()

	// sent to myself
	if rf.me == args.LeaderId {
		reply.Success = true
		return
	}

	// follower log is shorter so tell leader to decrease PrevLogIndex on next call
	if args.PrevLogIndex > len(rf.log)-1 {
		reply.NextIndex = len(rf.log)
		return
	}
	// index is acceptable but term is wrong
	// tell leader to call with next best (-1) index
	if rf.log[args.PrevLogIndex].Term != args.PrevLogTerm {
		reply.NextIndex = args.PrevLogIndex
		for reply.NextIndex > 1 {
			term := rf.log[args.PrevLogIndex].Term
			if rf.log[reply.NextIndex].Term == term {
				reply.NextIndex--
			} else {
				break
			}
		}
		return
	}

	// finally follower is ready to append entries
	// 1. remove extra entries
	if len(rf.log) > args.PrevLogIndex+1 {
		rf.log = rf.log[:args.PrevLogIndex+1]
		rf.persist()
	}
	// println("length of new log: ", len(rf.log))
	// 2. append entries sent by leader
	if len(args.Entries) != 0 {
		rf.log = append(rf.log, args.Entries...)
		rf.persist()
	}

	// is follower so update commit index
	if rf.commitIndex < args.LeaderCommit {
		if len(rf.log)-1 > args.LeaderCommit {
			rf.commitIndex = args.LeaderCommit
		} else {
			rf.commitIndex = len(rf.log) - 1
		}
	}
	reply.Success = true
	// println("Appended!")
}

// example code to send a RequestVote RPC to a server.
// server is the index of the target server in rf.peers[].
// expects RPC arguments in args.
// fills in *reply with RPC reply, so caller should
// pass &reply.
// the types of the args and reply passed to Call() must be
// the same as the types of the arguments declared in the
// handler function (including whether they are pointers).
//
// The labrpc package simulates a lossy network, in which servers
// may be unreachable, and in which requests and replies may be lost.
// Call() sends a request and waits for a reply. If a reply arrives
// within a timeout interval, Call() returns true; otherwise
// Call() returns false. Thus Call() may not return for a while.
// A false return can be caused by a dead server, a live server that
// can't be reached, a lost request, or a lost reply.
//
// Call() is guaranteed to return (perhaps after a delay) *except* if the
// handler function on the server side does not return.  Thus there
// is no need to implement your own timeouts around Call().
//
// look at the comments in ../labrpc/labrpc.go for more details.
//
// if you're having trouble getting RPC to work, check that you've
// capitalized all field names in structs passed over RPC, and
// that the caller passes the address of the reply struct with &, not
// the struct itself.
func (rf *Raft) sendRequestVote(server int, args *RequestVoteArgs, reply *RequestVoteReply) bool {
	ok := rf.peers[server].Call("Raft.RequestVote", args, reply)
	return ok
}

func (rf *Raft) sendAppendEntries(server int, args *AppendEntriesArgs, reply *AppendEntriesReply) bool {
	ok := rf.peers[server].Call("Raft.AppendEntries", args, reply)
	return ok
}

// GOOD
func (rf *Raft) sendThreat(peer int, term int) {
	rf.mu.Lock()
	// println(rf.me, ": Sending VoteRequest to", peer)
	defer rf.mu.Unlock()
	defer rf.persist()
	if rf.currentTerm != term {
		return
	}
	if rf.state != CANDIDATE {
		return
	}
	args := RequestVoteArgs{}
	reply := RequestVoteReply{}
	args.CandidateId = rf.me
	args.Term = rf.currentTerm
	args.LastLogIndex = len(rf.log) - 1
	args.LastLogTerm = rf.log[args.LastLogIndex].Term

	rf.mu.Unlock()
	ok := rf.sendRequestVote(peer, &args, &reply)
	rf.mu.Lock()

	if ok {
		// Candidate turned into follower OR leader before receiving reply
		if rf.state != CANDIDATE {
			return
		}
		// if voter replied with higher term turn candidate into follower
		if rf.currentTerm < reply.Term {
			rf.turnIntoFollower()
			rf.currentTerm = reply.Term
			rf.persist()
		}
		// if voter replied with voted granted
		if rf.currentTerm == args.Term && reply.VoteGranted {
			rf.votes[peer] = true
			rf.persist()
		}

		// check if got enough votes
		if rf.checkElectionWon() && rf.state != LEADER {
			rf.turnIntoLeader()
			rf.persist()
			term := rf.currentTerm
			for i := range rf.peers {
				go rf.sendHeartbeat(i, term)
			}
		}
	}
}

// GOOD
func (rf *Raft) sendHeartbeat(peer int, term int) {
	rf.mu.Lock()
	// println(rf.me, ": Sending heartbeat to", peer)
	defer rf.mu.Unlock()
	defer rf.persist()
	if rf.currentTerm != term {
		return
	}
	if rf.state != LEADER {
		return
	}
	args := AppendEntriesArgs{}
	reply := AppendEntriesReply{}
	args.LeaderId = rf.me
	args.Term = rf.currentTerm
	args.PrevLogIndex = len(rf.log) - 1
	args.PrevLogTerm = rf.log[args.PrevLogIndex].Term
	args.LeaderCommit = rf.commitIndex

	rf.mu.Unlock()
	ok := rf.sendAppendEntries(peer, &args, &reply)
	rf.mu.Lock()

	if ok {
		// Leader turned into follower before receiving reply
		if rf.state != LEADER {
			return
		}
		// Leader received higher term, turn into follower
		if rf.currentTerm < reply.Term {
			rf.turnIntoFollower()
			rf.currentTerm = reply.Term
		}
	}
}

// seperate from heartbeat
// arguments to peer include which logs they should replicate

// GOOD
func (rf *Raft) replicate(peer int, term int) {
	// println(rf.me, ": Sending replicate to", peer)
	rf.mu.Lock()
	defer rf.mu.Unlock()
	defer rf.persist()
	if rf.currentTerm != term {
		return
	}
	if rf.state != LEADER {
		return
	}
	if len(rf.log)-1 < rf.nextIndex[peer] {
		return
	}
	if len(rf.log)-1 == rf.matchIndex[peer] {
		return
	}
	length := len(rf.log)
	// initialize argument structure...
	args := AppendEntriesArgs{}
	reply := AppendEntriesReply{}
	args.Term = rf.currentTerm
	args.LeaderId = rf.me
	args.LeaderCommit = rf.commitIndex
	args.PrevLogIndex = rf.nextIndex[peer] - 1
	args.PrevLogTerm = -1
	args.Entries = make([]LogEntry, 0)
	for i := rf.nextIndex[peer]; i < len(rf.log); i++ {
		args.Entries = append(args.Entries, rf.log[i])
	}
	if rf.nextIndex[peer]-1 < len(rf.log) {
		args.PrevLogTerm = rf.log[rf.nextIndex[peer]-1].Term
	}

	rf.mu.Unlock()
	ok := rf.sendAppendEntries(peer, &args, &reply)
	rf.mu.Lock()

	if ok {
		// follower replied with higher term
		// turn leader into follower
		if rf.currentTerm < reply.Term {
			rf.turnIntoFollower()
			rf.currentTerm = reply.Term // change term, or stay same
			rf.persist()
		}

		// check if term was changed or length
		if rf.currentTerm == args.Term && len(rf.log) == length {
			// if follower replied with success then
			// all its logs are the same as our leaders
			if reply.Success {
				rf.matchIndex[peer] = len(rf.log) - 1
				rf.nextIndex[peer] = len(rf.log)
				rf.commit(peer)
			} else {
				// otherwise change the nextIndex of the follower
				// better optimization would be if we sent replicate() rpc again immediately but
				// in this case we just wait for next ticker update to send rpc call again
				if reply.NextIndex != -1 {
					rf.nextIndex[peer] = reply.NextIndex
				}
			}
		}
	}

}

// the service using Raft (e.g. a k/v server) wants to start
// agreement on the next command to be appended to Raft's log. if this
// server isn't the leader, returns false. otherwise start the
// agreement and return immediately. there is no guarantee that this
// command will ever be committed to the Raft log, since the leader
// may fail or lose an election. even if the Raft instance has been killed,
// this function should return gracefully.
//
// the first return value is the index that the command will appear at
// if it's ever committed. the second return value is the current
// term. the third return value is true if this server believes it is
// the leader.
func (rf *Raft) Start(command interface{}) (int, int, bool) {
	// Your code here (2B).
	rf.mu.Lock()
	defer rf.mu.Unlock()
	defer rf.persist()

	index := 0
	term := rf.currentTerm
	isLeader := rf.state == LEADER
	if !isLeader {
		return index, term, isLeader
	}
	// println("Adding new Command")
	index = len(rf.log)
	newLogEntry := LogEntry{}
	newLogEntry.Term = term
	newLogEntry.Index = index
	newLogEntry.Command = command

	rf.log = append(rf.log, newLogEntry)
	return index, term, isLeader
}

// the tester doesn't halt goroutines created by Raft after each test,
// but it does call the Kill() method. your code can use killed() to
// check whether Kill() has been called. the use of atomic avoids the
// need for a lock.
//
// the issue is that long-running goroutines use memory and may chew
// up CPU time, perhaps causing later tests to fail and generating
// confusing debug output. any goroutine with a long-running loop
// should call killed() to check whether it should stop.
func (rf *Raft) Kill() {
	atomic.StoreInt32(&rf.dead, 1)
	// Your code here, if desired.
}

func (rf *Raft) killed() bool {
	z := atomic.LoadInt32(&rf.dead)
	return z == 1
}

func (rf *Raft) checkElectionWon() bool {
	votes := 0
	for i := range rf.peers {
		if rf.votes[i] {
			votes++
		}
	}
	return votes > len(rf.peers)/2
}

// turn into leader
func (rf *Raft) turnIntoLeader() {
	// println(rf.me, ": Won Election")
	rf.state = LEADER
	for i := range rf.peers {
		rf.nextIndex[i] = len(rf.log)
		rf.matchIndex[i] = 0
	}
}

// Turn into candidate
func (rf *Raft) turnIntoCandidate() {
	rf.state = CANDIDATE
	rf.currentTerm++
	rf.votedFor = rf.me
	rf.resetVotes()
	rf.votes[rf.me] = true
}

// Turn into follower
func (rf *Raft) turnIntoFollower() {
	rf.state = FOLLOWER
	rf.votedFor = -1
	rf.resetVotes()
}

func (rf *Raft) ticker() {
	for !rf.killed() {
		// Your code here (2A)
		// Check if a leader election should be started.
		rf.mu.Lock()
		if rf.ifTimeout() {
			rf.turnIntoCandidate()
			rf.last = time.Now()
			rf.resetTimeout()
			rf.persist()
			term := rf.currentTerm
			for i := range rf.peers {
				if i != rf.me {
					go rf.sendThreat(i, term)
				}
			}
		}
		rf.mu.Unlock()
		// pause for a random amount of time between 50 and 350
		// milliseconds.
		ms := 50 + (rand.Int63() % 300)
		time.Sleep(time.Millisecond * time.Duration(ms))
	}
}

func (rf *Raft) leaderTicker() {
	for !rf.killed() {
		rf.mu.Lock()

		if rf.state == LEADER {
			term := rf.currentTerm
			for i := range rf.peers {
				go rf.sendHeartbeat(i, term)
			}
		}

		rf.mu.Unlock()
		ms := 400 + (rand.Int63() % 100)
		time.Sleep(time.Duration(ms) * time.Millisecond)
	}
}

func (rf *Raft) replicateTicker() {
	for !rf.killed() {
		rf.mu.Lock()

		if rf.state == LEADER {
			// println("Sending replicates!")
			// println("Log size is:", len(rf.log))
			term := rf.currentTerm
			for i := range rf.peers {
				if i != rf.me {
					go rf.replicate(i, term)
				}
			}
		}

		rf.mu.Unlock()
		// println("replicate sleeping for:", ms)
		ms := 50 + (rand.Int63() % 200)
		time.Sleep(time.Duration(ms) * time.Millisecond)
	}
}

func (rf *Raft) commitTicker() {
	for !rf.killed() {
		rf.mu.Lock()
		if rf.state == LEADER {
			for i := len(rf.log) - 1; rf.commitIndex < i; i-- {
				counter := 0
				for j := range rf.peers {
					if j != rf.me && rf.matchIndex[j] >= i {
						counter++
					}
				}
				if counter*2 >= len(rf.peers)-1 && rf.log[i].Term == rf.currentTerm {
					rf.commitIndex = i
					// println("Commited!", rf.commitIndex)
					break
				}
			}
		}

		rf.mu.Unlock()
		// println("commit sleeping for:", ms)
		ms := 100 + (rand.Int63() % 100)
		time.Sleep(time.Duration(ms) * time.Millisecond)
	}
}

func (rf *Raft) commit(peer int) {
	var counter = 0
	var nextIndex = rf.matchIndex[peer]

	if nextIndex > rf.commitIndex {
		for i := 0; i < len(rf.peers); i++ {
			if i != rf.me && rf.matchIndex[i] >= nextIndex {
				counter++
			}
		}
		if counter*2 >= len(rf.peers)-1 && rf.log[nextIndex].Term == rf.currentTerm {
			rf.commitIndex = nextIndex
		}
	}
}

// CORRECT
func (rf *Raft) applyTicker() {
	for !rf.killed() {
		rf.mu.Lock()
		for rf.lastApplied < rf.commitIndex {
			logEntry := rf.log[rf.lastApplied+1]
			newMsg := ApplyMsg{}
			newMsg.Command = logEntry.Command
			newMsg.CommandIndex = rf.lastApplied + 1
			newMsg.CommandValid = true

			rf.lastApplied++
			rf.applyCh <- newMsg
			// println("Sending applymsg!")
		}

		rf.mu.Unlock()
		// println("apply sleeping for:", ms)
		ms := 400 + (rand.Int63() % 150)
		time.Sleep(time.Duration(ms) * time.Millisecond)
	}
}

// the service or tester wants to create a Raft server. the ports
// of all the Raft servers (including this one) are in peers[]. this
// server's port is peers[me]. all the servers' peers[] arrays
// have the same order. persister is a place for this server to
// save its persistent state, and also initially holds the most
// recent saved state, if any. applyCh is a channel on which the
// tester or service expects Raft to send ApplyMsg messages.
// Make() must return quickly, so it should start goroutines
// for any long-running work.
func Make(peers []*labrpc.ClientEnd, me int,
	persister *Persister, applyCh chan ApplyMsg) *Raft {
	rf := &Raft{}
	rf.peers = peers
	rf.persister = persister
	rf.me = me

	// Your initialization code here (2A, 2B, 2C).
	rf.currentTerm = 0
	rf.votedFor = -1
	rf.state = FOLLOWER
	rf.lastApplied = 0
	rf.log = append(rf.log, LogEntry{}) // blank entry

	rf.votes = make([]bool, len(peers))
	rf.nextIndex = make([]int, len(peers))
	rf.matchIndex = make([]int, len(peers))
	for i := range rf.peers {
		rf.votes[i] = false
		rf.nextIndex[i] = 1
		rf.matchIndex[i] = 0
	}
	rf.applyCh = applyCh

	rf.resetTimeout()

	// initialize from state persisted before a crash
	rf.readPersist(persister.ReadRaftState())

	// start all tickers
	rf.startTickers()

	return rf
}

func (rf *Raft) startTickers() {
	go rf.ticker()
	go rf.leaderTicker()
	go rf.replicateTicker()
	go rf.commitTicker()
	go rf.applyTicker()
}
