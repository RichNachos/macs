package mr

import (
	"log"
	"net"
	"net/http"
	"net/rpc"
	"os"
	"strconv"
	"sync"
	"time"
)

type Coordinator struct {
	// Your definitions here.
	coordinatorLock sync.Mutex
	done            bool
	nReduce         int
	files           []string
	taskId          int
	phase           TaskType
	statuses        []Status
	tasks           []string
}

// Your code here -- RPC handlers for the worker to call.

// an example RPC handler.
//
// the RPC argument and reply types are defined in rpc.go.
func (c *Coordinator) Example(args *ExampleArgs, reply *ExampleReply) error {
	reply.Y = args.X + 1
	return nil
}

// Handles rpc's from workers during MAP and REDUCE phases
func (c *Coordinator) RequestTask(args *Args, reply *Reply) error {
	c.coordinatorLock.Lock()
	defer c.coordinatorLock.Unlock()

	waiting := false
	for i := 0; i < len(c.tasks); i += 1 {
		if c.statuses[i] == READY {
			reply.Task = c.phase
			c.statuses[i] = IN_PROGRESS
			reply.Input = c.tasks[i]
			reply.NReduce = c.nReduce
			reply.TaskId = i
			go WaitForWorker(c, i)
			return nil
		} else if c.statuses[i] == IN_PROGRESS {
			waiting = true
		}
	}

	if waiting {
		reply.Task = WAIT
	}
	return nil
}

func NextPhase(c *Coordinator) {
	if c.phase == MAP {
		c.phase = REDUCE
		LoadReducePhase(c)
	} else if c.phase == REDUCE {
		c.phase = FINISHED
		c.done = true
	}
}

// Lock must be picked up before this function is called!
// Loads values into coordinator for map phase
func LoadMapPhase(c *Coordinator) {
	// println("Loading Map Phase")
	n := len(c.files)
	c.tasks = make([]string, n)
	c.statuses = make([]Status, n)
	for i := 0; i < n; i += 1 {
		c.tasks[i] = c.files[i]
		c.statuses[i] = READY
	}
}

// Lock must be picked up before this function is called!
// Loads values into coordinator for reduce phase
func LoadReducePhase(c *Coordinator) {
	// println("Loading Reduce Phase")
	n := c.nReduce
	c.tasks = make([]string, n)
	c.statuses = make([]Status, n)
	for i := 0; i < n; i += 1 {
		c.tasks[i] = strconv.Itoa(i)
		c.statuses[i] = READY
	}
}

// Workers call this function to notify coordinator of task finish
func (c *Coordinator) Signal(args *SignalArgs, reply *SignalReply) error {
	// println("Task Done: ", args.TaskId)
	c.coordinatorLock.Lock()
	defer c.coordinatorLock.Unlock()
	c.statuses[args.TaskId] = DONE
	done := true
	for i := 0; i < len(c.tasks); i += 1 {
		if c.statuses[i] != DONE {
			done = false
			break
		}
	}
	if done {
		NextPhase(c)
	}

	return nil
}

// go subroutine that checks if the task is done by worker after 10 seconds
// if not will schedule the same task again
func WaitForWorker(c *Coordinator, taskId int) {
	time.Sleep(WorkerDieTime)
	c.coordinatorLock.Lock()
	defer c.coordinatorLock.Unlock()

	if c.statuses[taskId] == IN_PROGRESS {
		c.statuses[taskId] = READY
	}
}

// start a thread that listens for RPCs from worker.go
func (c *Coordinator) server() {
	rpc.Register(c)
	rpc.HandleHTTP()
	//l, e := net.Listen("tcp", ":1234")
	sockname := coordinatorSock()
	os.Remove(sockname)
	l, e := net.Listen("unix", sockname)
	if e != nil {
		log.Fatal("listen error:", e)
	}
	go http.Serve(l, nil)
}

// main/mrcoordinator.go calls Done() periodically to find out
// if the entire job has finished.
func (c *Coordinator) Done() bool {
	// Your code here.
	c.coordinatorLock.Lock()
	defer c.coordinatorLock.Unlock()
	return c.done
}

// create a Coordinator.
// main/mrcoordinator.go calls this function.
// nReduce is the number of reduce tasks to use.
func MakeCoordinator(files []string, nReduce int) *Coordinator {
	c := Coordinator{}

	// Your code here.
	c.coordinatorLock.Lock()
	c.done = false
	c.nReduce = nReduce
	c.files = files
	c.taskId = 0
	c.phase = MAP
	LoadMapPhase(&c)
	c.coordinatorLock.Unlock()

	c.server()
	return &c
}
