#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"


int
main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Error: Too few arguments\n");
        exit(1);
    }

    char* command = argv[1];
    
    while (1) {
        char buf[100];
        char c[1];
        int i = 0;
        int arg_count = 1;
        if(read(0, c, 1) == 0) {
            break;
        }
        
        while (c[0] != '\n') {
            buf[i++] = c[0];
            if (c[0] == ' ') {
                arg_count++;
            }
            read(0, c, 1);
        }
        buf[i] = '\0';
        
        // Calculate total arguments and allocate big enough string array in the stack
        int tot_args = arg_count + argc - 1;
        char* arguments[tot_args];
        
        // Load xargs arguments first into arguments array
        int j = 0;
        for (; j < argc - 1; j++) {
            arguments[j] = argv[j + 1];
        }
        for (; j < tot_args; j++) {
            arguments[j] = buf;
        }
        arguments[j] = 0;

        int pid = fork();
        if (pid == 0) {
            exec(command, arguments);
            printf("Exec failed!\n");
            exit(1);
        } else {
            wait((int *) 0);
        }
    }
    
    exit(0);
}