#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[]) {
    if (argc > 1) {
        printf("Error: no arguments needed\n");
        exit(1);
    }

    int fds[2];
    pipe(fds);
    int pid = fork();
    if (pid == 0) {
        close(fds[1]);
        int buf[34];
        int n = read(fds[0], buf, 34 * 4); // Read ints from 2..35 (inclusive)
        int j = 0;
        close(fds[0]);
        
        while (1) {
            pipe(fds);
            pid = fork();
            if (pid > 0) {
                close(fds[0]);
                printf("prime %d\n", buf[0]);
                int new_buf[34]; j = 0;
                for (int i = 1; i < n / 4; i++) {
                    if (buf[i] % buf[0] != 0) {
                        new_buf[j++] = buf[i];
                    }
                }
                write(fds[1], new_buf, j * 4);
                close(fds[1]);
                wait((int *) 0);
                exit(0);
            } else {
                close(fds[1]);
                n = read(fds[0], buf, 34 * 4);
                if (n == 0) exit(0);
                close(fds[0]);
            }
        }

        wait((int *) 0);
        exit(0);
    } else {
        close(fds[0]);
        int buf[34];
        for (int i = 2; i <= 35; i++) {
            buf[i-2] = i;
        }
        write(fds[1], buf, 34 * 4);
        //printf("parent: waiting for child...\n");
        close(fds[1]);
        wait((int *) 0);
        //printf("parent: child exited\n");
        exit(0);
    }
    exit(0);
}